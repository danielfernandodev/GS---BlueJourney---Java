package br.com.fiap.bo;

import br.com.fiap.beans.Evento;
import br.com.fiap.dao.EventoDAO;

import java.sql.SQLException;
import java.util.List;

/**
 * Classe de negócios para a entidade Evento.
 */
public class EventoBO {

    private EventoDAO eventoDAO;

    public EventoBO(EventoDAO eventoDAO) {
        this.eventoDAO = eventoDAO;
    }

    public void inserirBO(Evento evento) throws SQLException {
        eventoDAO.inserir(evento);
    }

    public void atualizarBO(Evento evento) throws SQLException {
        eventoDAO.atualizar(evento);
    }

    public void deletarBO(String nome) throws SQLException {
        eventoDAO.deletar(nome);
    }

    public List<Evento> selecionarBO() throws SQLException {
        return eventoDAO.selecionar();
    }

}
