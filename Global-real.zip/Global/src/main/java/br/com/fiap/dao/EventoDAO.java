package br.com.fiap.dao;

import br.com.fiap.beans.Evento;
import java.sql.SQLException;
import java.util.List;

/**
 * Interface para operações de banco de dados relacionadas à entidade Evento.
 */
public interface EventoDAO {

   
    String inserir(Evento evento) throws SQLException;

  
    String deletar(String nome) throws SQLException;

 
    String atualizar(Evento evento) throws SQLException;

    
    List<Evento> selecionar() throws SQLException;
}
