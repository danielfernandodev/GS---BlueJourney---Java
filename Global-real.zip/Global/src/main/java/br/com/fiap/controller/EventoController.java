package br.com.fiap.controller;

import br.com.fiap.beans.Evento;
import br.com.fiap.bo.EventoBO;
import br.com.fiap.dao.impl.EventoDAOImpl;

import java.sql.SQLException;
import java.util.List;

/**
 * Controlador para operações relacionadas a Evento.
 */
public class EventoController {

    private EventoBO eventoBO;

    public EventoController() throws ClassNotFoundException, SQLException {
        this.eventoBO = new EventoBO(new EventoDAOImpl());
    }

    public String inserirEvento(Evento evento) {
        try {
            eventoBO.inserirBO(evento);
            return "Evento cadastrado com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao cadastrar evento: " + e.getMessage();
        }
    }

    public String deletarEvento(String nome) {
        try {
            eventoBO.deletarBO(nome);
            return "Evento deletado com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao deletar evento: " + e.getMessage();
        }
    }

    public String atualizarEvento(Evento evento) {
        try {
            eventoBO.atualizarBO(evento);
            return "Evento atualizado com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar evento: " + e.getMessage();
        }
    }

    public List<Evento> listarEventos() {
        try {
            return eventoBO.selecionarBO();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
