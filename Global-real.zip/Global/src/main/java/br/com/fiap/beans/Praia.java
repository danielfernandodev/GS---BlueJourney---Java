package br.com.fiap.beans;

public class Praia {
	
	private String nome;
	private String local;
	private String status;
	
	public Praia(String nome, String local, String status) {
		super();
		this.nome = nome;
		this.local = local;
		this.status = status;
	}

	public Praia() {
		// TODO Auto-generated constructor stub
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Praia [nome=" + nome + ", local=" + local + ", status=" + status + ", getNome()=" + getNome()
				+ ", getLocal()=" + getLocal() + ", getStatus()=" + getStatus() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
