package br.com.fiap.controller;

import br.com.fiap.beans.Usuario;
import br.com.fiap.bo.UsuarioBO;
import br.com.fiap.dao.impl.UsuarioDAOImpl;

import java.sql.SQLException;
import java.util.List;

/**
 * Controlador para operações relacionadas a Usuario.
 */
public class UsuarioController {

    private UsuarioBO usuarioBO;

    public UsuarioController() throws ClassNotFoundException, SQLException {
        this.usuarioBO = new UsuarioBO(new UsuarioDAOImpl());
    }

    public String inserirUsuario(Usuario usuario) {
        try {
            usuarioBO.inserirBO(usuario);
            return "Usuário cadastrado com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao cadastrar usuário: " + e.getMessage();
        }
    }

    public String deletarUsuario(String email) {
        try {
            usuarioBO.deletarBO(email);
            return "Usuário deletado com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao deletar usuário: " + e.getMessage();
        }
    }

    public String atualizarUsuario(Usuario usuario) {
        try {
            usuarioBO.atualizarBO(usuario);
            return "Usuário atualizado com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar usuário: " + e.getMessage();
        }
    }

    public List<Usuario> listarUsuarios() {
        try {
            return usuarioBO.selecionarBO();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
