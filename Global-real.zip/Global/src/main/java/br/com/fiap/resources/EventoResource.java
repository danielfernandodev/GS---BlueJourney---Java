package br.com.fiap.resources;

import br.com.fiap.beans.Evento;
import br.com.fiap.controller.EventoController;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import java.sql.SQLException;
import java.util.List;

@Path("/Evento")
public class EventoResource {

	private EventoController eventoController;

	public EventoResource() throws ClassNotFoundException, SQLException {
		this.eventoController = new EventoController();
	}

	@POST
	@Path("/inserir")
	@Consumes("application/json")
	public Response inserirEvento(Evento evento, @Context UriInfo uriInfo) throws ClassNotFoundException, SQLException {
		String resultado = eventoController.inserirEvento(evento);
		System.out.println("Dados recebidos: " + evento);
		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
		builder.path(evento.getNome());
		return Response.created(builder.build()).entity(resultado).build();
	}

	@PUT
	@Path("/{nome}")
	@Consumes("application/json")
	public Response atualizarEvento(Evento evento, @PathParam("nome") String nome) throws ClassNotFoundException, SQLException {
		evento.setNome(nome);
		String resultado = eventoController.atualizarEvento(evento);
		System.out.println("Dados recebidos: " + evento);
		return Response.ok().entity(resultado).build();
	}

	@DELETE
	@Path("/{nome}")
	public Response deletarEvento(@PathParam("nome") String nome) throws ClassNotFoundException, SQLException {
		String resultado = eventoController.deletarEvento(nome);
		return Response.ok().entity(resultado).build();
	}

	@GET
	@Produces("application/json")
	public List<Evento> listarEventos() throws ClassNotFoundException, SQLException {
		return eventoController.listarEventos();
	}
}
