package br.com.fiap.beans;

import java.sql.Date;
import java.sql.Timestamp;

public class Evento {
	
	private String nome;
	private String local;
	private Timestamp data;
	private String descricao;
	
	public Evento(String nome, String local, Timestamp data, String descricao) {
		super();
		this.nome = nome;
		this.local = local;
		this.data = data;
		this.setDescricao(descricao);
	}

	public Evento() {
		// TODO Auto-generated constructor stub
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

	public Timestamp getData() {
		return data;
	}

	public void setData(Timestamp data) {
		this.data = data;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public String toString() {
		return "Nome: " + getNome() +
				"\nLocal: " + getLocal() +
				"\nDescrição: " + getDescricao();
	}
	
	

}
