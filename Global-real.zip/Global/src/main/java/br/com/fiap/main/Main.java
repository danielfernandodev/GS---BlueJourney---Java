	package br.com.fiap.main;
	
	import java.sql.SQLException;
	
	import br.com.fiap.beans.Usuario;
	import br.com.fiap.dao.impl.UsuarioDAOImpl;
	
	public class Main {
		
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
	        
	        UsuarioDAOImpl usuarioDao = new UsuarioDAOImpl();
	        Usuario usuario = new Usuario();
	        
	        usuario.setNome("daniel2");	
	        usuario.setEmail("daniel@123");
	        usuario.setTelefone("22222");
	        usuario.setSenha("22222");
	        
	        usuarioDao.inserir(usuario);
	        
	}
	}
