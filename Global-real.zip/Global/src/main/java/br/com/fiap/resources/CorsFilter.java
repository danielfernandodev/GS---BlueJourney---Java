package br.com.fiap.resources;

import java.io.IOException;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.MultivaluedMap;

public class CorsFilter implements ContainerResponseFilter {

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext)
            throws IOException {

        MultivaluedMap<String, Object> headers = responseContext.getHeaders();

        // Allow from specific origin
        headers.add("Access-Control-Allow-Origin", "http://localhost:3000");

        // Allow specific methods
        headers.add("Access-Control-Allow-Methods", "OPTIONS, GET, POST, PUT, DELETE, HEAD");

        // Allow specific headers
        headers.add("Access-Control-Allow-Headers",
                "Content-Type, X-Requested-With, Accept, Origin, Authorization");

        // Allow credentials
        headers.add("Access-Control-Allow-Credentials", "true");
    }
}
