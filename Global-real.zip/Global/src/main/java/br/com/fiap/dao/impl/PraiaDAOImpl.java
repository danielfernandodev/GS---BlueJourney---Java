package br.com.fiap.dao.impl;

import br.com.fiap.beans.Praia;
import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.dao.PraiaDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementação da interface PraiaDAO para operações de banco de dados.
 */
public class PraiaDAOImpl implements PraiaDAO {

    private Connection minhaConexao;

    public PraiaDAOImpl() throws ClassNotFoundException, SQLException {
        try {
            this.minhaConexao = new ConexaoFactory().conexao();
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
            throw e; // Re-throw the exception after logging it
        }
    }

    @Override
    public String inserir(Praia praia) throws SQLException {
        String sql = "INSERT INTO Praia (nome, local, status) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setString(1, praia.getNome());
            stmt.setString(2, praia.getLocal());
            stmt.setString(3, praia.getStatus());
            stmt.execute();
            return "Cadastrado com Sucesso!";
        } catch (SQLException e) {
            System.err.println("Erro ao inserir praia: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public String deletar(String nome) throws SQLException {
        String sql = "DELETE FROM Praia WHERE nome = ?";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.execute();
            return "Deletado com Sucesso!";
        } catch (SQLException e) {
            System.err.println("Erro ao deletar praia: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public String atualizar(Praia praia) throws SQLException {
        String sql = "UPDATE Praia SET local = ?, status = ? WHERE nome = ?";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setString(1, praia.getLocal());
            stmt.setString(2, praia.getStatus());
            stmt.setString(3, praia.getNome());
            stmt.executeUpdate();
            return "Atualizado com Sucesso!";
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar praia: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public List<Praia> selecionar() throws SQLException {
        List<Praia> listaPraia = new ArrayList<>();
        String sql = "SELECT * FROM Praia";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Praia praia = new Praia();
                praia.setNome(rs.getString("nome"));
                praia.setLocal(rs.getString("local"));
                praia.setStatus(rs.getString("status"));
                listaPraia.add(praia);
            }
            return listaPraia;
        } catch (SQLException e) {
            System.err.println("Erro ao selecionar praias: " + e.getMessage());
            throw e;
        }
    }
}
