package br.com.fiap.services;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.sql.SQLException;


import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import br.com.fiap.beans.Usuario;
import br.com.fiap.dao.impl.UsuarioDAOImpl;

public class UsuarioService {
	
	public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/Pages/Cadastro", new CadastroHandler());
        server.setExecutor(null); // default executor
        server.start();
        System.out.println("Servidor iniciado na porta 8000...");
    }

	 static class CadastroHandler implements HttpHandler {
	        @Override
	        public void handle(HttpExchange exchange) throws IOException {
	            // Obter os valores dos campos do formulário
	            String nome = null, email = null, telefone = null, senha = null;
	            String query = exchange.getRequestURI().getQuery();
	            if (query != null) {
	                String[] params = query.split("&");
	                for (String param : params) {
	                    String[] keyValue = param.split("=");
	                    String key = keyValue[0];
	                    String value = keyValue.length > 1 ? keyValue[1] : "";
	                    if (key.equals("nome")) {
	                        nome = value;
	                    } else if (key.equals("email")) {
	                        email = value;
	                    } else if (key.equals("telefone")) {
	                        telefone = value;
	                    } else if (key.equals("senha")) {
	                        senha = value;
	                }
	            }

		            // Exibir os dados na console (apenas para fins de teste)
		            System.out.println("Nome: " + nome);
		            System.out.println("Email: " + email);
		            System.out.println("Telefone: " + telefone);
		            System.out.println("Senha: " + senha);
		            
            Usuario usuario = new Usuario();
            
            
            usuario.setEmail(email);
            usuario.setNome(nome);
            usuario.setSenha(senha);
          
            UsuarioDAOImpl usuarioDao = null;
			try {
				usuarioDao = new UsuarioDAOImpl();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
            try {
				usuarioDao.inserir(usuario);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	            }
	        }
	 }
}
