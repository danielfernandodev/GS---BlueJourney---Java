package br.com.fiap.bo;

import br.com.fiap.beans.Praia;
import br.com.fiap.dao.PraiaDAO;

import java.sql.SQLException;
import java.util.List;

/**
 * Classe de negócios para a entidade Praia.
 */
public class PraiaBO {

    private PraiaDAO praiaDAO;

    public PraiaBO(PraiaDAO praiaDAO) {
        this.praiaDAO = praiaDAO;
    }

    public void inserirBO(Praia praia) throws SQLException {
        praiaDAO.inserir(praia);
    }

    public void atualizarBO(Praia praia) throws SQLException {
        praiaDAO.atualizar(praia);
    }

    public void deletarBO(String nome) throws SQLException {
        praiaDAO.deletar(nome);
    }

    public List<Praia> selecionarBO() throws SQLException {
        return praiaDAO.selecionar();
    }

}
