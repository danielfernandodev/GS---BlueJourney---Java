package br.com.fiap.resources;

import br.com.fiap.beans.Usuario;
import br.com.fiap.controller.UsuarioController;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import java.sql.SQLException;
import java.util.List;

@Path("/Usuario")
public class UsuarioResource {

    private UsuarioController usuarioController;

    public UsuarioResource() throws ClassNotFoundException, SQLException {
        this.usuarioController = new UsuarioController();
    }

    @POST
    @Path("/inserir")
    @Consumes("application/json")
    public Response cadastroRs(Usuario usuario, @Context UriInfo uriInfo) throws ClassNotFoundException, SQLException {
        String resultado = usuarioController.inserirUsuario(usuario);
        System.out.println("Dados recebidos: " + usuario);
        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(usuario.getEmail());
        return Response.created(builder.build()).entity(resultado).build();
    }

    @PUT
    @Path("/{email}")
    @Consumes("application/json")
    public Response atualizaRs(Usuario usuario, @PathParam("email") String email) throws ClassNotFoundException, SQLException {
        usuario.setEmail(email);
        String resultado = usuarioController.atualizarUsuario(usuario);
        return Response.ok().entity(resultado).build();
    }

    @DELETE
    @Path("/{email}")
    public Response deletarRs(@PathParam("email") String email) throws ClassNotFoundException, SQLException {
        String resultado = usuarioController.deletarUsuario(email);
        return Response.ok().entity(resultado).build();
    }

    @GET
    @Path("/listar")
    @Produces("application/json")
    public List<Usuario> listarUsuarios() throws ClassNotFoundException, SQLException {
        return usuarioController.listarUsuarios();
    }
}
