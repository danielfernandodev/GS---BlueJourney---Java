package br.com.fiap.dao;

import br.com.fiap.beans.Usuario;
import java.sql.SQLException;
import java.util.List;

/**
 * Interface para operações de banco de dados relacionadas à entidade Usuario.
 */
public interface UsuarioDAO {

  
    String inserir(Usuario usuario) throws SQLException;

    
    String deletar(String email) throws SQLException;

    
    String atualizar(Usuario usuario) throws SQLException;

   
    List<Usuario> selecionar() throws SQLException;
}
