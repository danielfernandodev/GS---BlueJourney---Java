package br.com.fiap.controller;

import br.com.fiap.beans.Praia;
import br.com.fiap.bo.PraiaBO;
import br.com.fiap.dao.impl.PraiaDAOImpl;

import java.sql.SQLException;
import java.util.List;

/**
 * Controlador para operações relacionadas a Praia.
 */
public class PraiaController {

    private PraiaBO praiaBO;

    public PraiaController() throws ClassNotFoundException, SQLException {
        this.praiaBO = new PraiaBO(new PraiaDAOImpl());
    }

    public String inserirPraia(Praia praia) {
        try {
            praiaBO.inserirBO(praia);
            return "Praia cadastrada com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao cadastrar praia: " + e.getMessage();
        }
    }

    public String deletarPraia(String nome) {
        try {
            praiaBO.deletarBO(nome);
            return "Praia deletada com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao deletar praia: " + e.getMessage();
        }
    }

    public String atualizarPraia(Praia praia) {
        try {
            praiaBO.atualizarBO(praia);
            return "Praia atualizada com sucesso!";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Erro ao atualizar praia: " + e.getMessage();
        }
    }

    public List<Praia> listarPraias() {
        try {
            return praiaBO.selecionarBO();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
