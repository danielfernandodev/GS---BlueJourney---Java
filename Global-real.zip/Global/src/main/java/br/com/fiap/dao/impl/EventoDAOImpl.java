package br.com.fiap.dao.impl;

import br.com.fiap.beans.Evento;
import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.dao.EventoDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementação da interface EventoDAO para operações de banco de dados.
 */
public class EventoDAOImpl implements EventoDAO {

    public Connection minhaConexao;

    public EventoDAOImpl() throws ClassNotFoundException, SQLException {
        try {
            this.minhaConexao = new ConexaoFactory().conexao();
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
            throw e; // Re-throw the exception after logging it
        }
    }

    @Override
    public String inserir(Evento evento) throws SQLException {
        String sql = "INSERT INTO Evento (nome, local, data, descricao) VALUES (?, ?, sysdate, ?)";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setString(1, evento.getNome());
            stmt.setString(2, evento.getLocal());
            stmt.setString(3, evento.getDescricao());
            stmt.execute();
            return "Cadastrado com Sucesso!";
        } catch (SQLException e) {
            System.err.println("Erro ao inserir evento: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public String deletar(String nome) throws SQLException {
        String sql = "DELETE FROM Evento WHERE nome = ?";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.execute();
            return "Deletado com Sucesso!";
        } catch (SQLException e) {
            System.err.println("Erro ao deletar evento: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public String atualizar(Evento evento) throws SQLException {
        String sql = "UPDATE Evento SET local = ?, data = ?, descricao = ? WHERE nome = ?";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setString(1, evento.getLocal());
            stmt.setDate(2, new Date(evento.getData().getTime()));
            stmt.setString(3, evento.getDescricao());
            stmt.setString(4, evento.getNome());
            stmt.executeUpdate();
            return "Atualizado com Sucesso!";
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar evento: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public List<Evento> selecionar() throws SQLException {
        List<Evento> listaEvento = new ArrayList<>();
        String sql = "SELECT * FROM Evento";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Evento evento = new Evento();
                evento.setNome(rs.getString("nome"));
                evento.setLocal(rs.getString("local"));
                evento.setDescricao(rs.getString("descricao"));
                listaEvento.add(evento);
            }
            return listaEvento;
        } catch (SQLException e) {
            System.err.println("Erro ao selecionar eventos: " + e.getMessage());
            throw e;
        }
    }
}
