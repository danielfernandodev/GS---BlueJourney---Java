package br.com.fiap.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Usuario;
import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.dao.UsuarioDAO;

public class UsuarioDAOImpl implements UsuarioDAO {

    public Connection minhaConexao;

    public UsuarioDAOImpl() throws ClassNotFoundException, SQLException {
        try {
            this.minhaConexao = new ConexaoFactory().conexao();
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
            throw e; // Re-throw the exception after logging it
        }
    }

    // Insert 
    public String inserir(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO Usuario (nome, email, telefone, senha) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getTelefone());
            stmt.setString(4, usuario.getSenha());
            stmt.execute();
            return "Cadastrado com Sucesso!";
        } catch (SQLException e) {
            System.err.println("Erro ao inserir usuário: " + e.getMessage());
            throw e;
        }
    }

    // Delete
    public String deletar(String email) throws SQLException {
        String sql = "DELETE FROM Usuario WHERE email = ?";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.execute();
            return "Deletado com Sucesso!";
        } catch (SQLException e) {
            System.err.println("Erro ao deletar usuário: " + e.getMessage());
            throw e;
        }
    }

    // Update 
    public String atualizar(Usuario usuario) throws SQLException {
        String sql = "UPDATE Usuario SET nome = ?, telefone = ?, senha = ? WHERE email = ?";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getTelefone());
            stmt.setString(3, usuario.getSenha());
            stmt.setString(4, usuario.getEmail());
            stmt.executeUpdate();
            return "Atualizado com Sucesso!";
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar usuário: " + e.getMessage());
            throw e;
        }
    }

    // Select 
    public List<Usuario> selecionar() throws SQLException {
        List<Usuario> listaUsuario = new ArrayList<>();
        String sql = "SELECT * FROM Usuario";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setNome(rs.getString("nome"));
                usuario.setEmail(rs.getString("email"));
                usuario.setTelefone(rs.getString("telefone"));
                listaUsuario.add(usuario);
            }
            return listaUsuario;
        } catch (SQLException e) {
            System.err.println("Erro ao selecionar usuários: " + e.getMessage());
            throw e;
        }
    }
}
