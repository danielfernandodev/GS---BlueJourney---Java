package br.com.fiap.dao;

import br.com.fiap.beans.Praia;
import java.sql.SQLException;
import java.util.List;

/**
 * Interface para operações de banco de dados relacionadas à entidade Praia.
 */
public interface PraiaDAO {

    
    String inserir(Praia praia) throws SQLException;

    
    String deletar(String nome) throws SQLException;

    
    String atualizar(Praia praia) throws SQLException;

  
    List<Praia> selecionar() throws SQLException;
}
