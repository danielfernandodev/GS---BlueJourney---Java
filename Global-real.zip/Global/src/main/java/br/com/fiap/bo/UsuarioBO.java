package br.com.fiap.bo;

import br.com.fiap.beans.Usuario;
import br.com.fiap.dao.UsuarioDAO;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Pattern;


public class UsuarioBO {

    private UsuarioDAO usuarioDAO;

    public UsuarioBO(UsuarioDAO usuarioDAO) {
        this.usuarioDAO = usuarioDAO;
    }

    public void inserirBO(Usuario usuario) throws SQLException {
        usuarioDAO.inserir(usuario);
    }

    public void atualizarBO(Usuario usuario) throws SQLException {
        usuarioDAO.atualizar(usuario);
    }

    public void deletarBO(String email) throws SQLException {
        usuarioDAO.deletar(email);
    }

    public List<Usuario> selecionarBO() throws SQLException {
        return usuarioDAO.selecionar();
    }

 }
