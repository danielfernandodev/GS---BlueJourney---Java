package br.com.fiap.services;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import br.com.fiap.beans.Evento;
import br.com.fiap.dao.impl.EventoDAOImpl;

public class EventoService {
	

	public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/Pages/Portal", new CadastroHandler());
        server.setExecutor(null); // default executor
        server.start();
        System.out.println("Servidor iniciado na porta 8000...");
    }

	 static class CadastroHandler implements HttpHandler {
	        @Override
	        public void handle(HttpExchange exchange) throws IOException {
	            // Obter os valores dos campos do formulário
	            String nome = null, local = null;
	            Date data = null;
	            String query = exchange.getRequestURI().getQuery();
	            if (query != null) {
	                String[] params = query.split("&");
	                for (String param : params) {
	                    String[] keyValue = param.split("=");
	                    String key = keyValue[0];
	                    String value = keyValue.length > 1 ? keyValue[1] : "";
	                   
	                    if (key.equals("nome")) {
	                        nome = value;
	                    } else if (key.equals("local")) {
	                        local = value;
	                    } else if (key.equals("data")) {
	                        // Analise a string da data usando um formatador
	                        try {
	                            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); // Ajuste o formato com base no formato esperado
	                            data = (Date) formatter.parse(value);
	                        } catch (ParseException e) {
	                            // Lidar com exceção de análise (por exemplo, registrar o erro ou fornecer uma mensagem amigável ao usuário)
	                            System.err.println("Erro ao analisar data: " + e.getMessage());
	                        }
	                    }
	                }

		            // Exibir os dados na console (apenas para fins de teste)
		            System.out.println("Nome: " + nome);
		            System.out.println("Local: " + local);
		            System.out.println("Data: " + data);
		        		            
            Evento evento = new Evento();
            
           evento.setNome(nome);
           evento.setLocal(local);

          
            EventoDAOImpl EventoDao = null;
			try {
				EventoDao = new EventoDAOImpl();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
            try {
            	EventoDao.inserir(evento);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	            }
	        }
	 }

}

